//
//  ViewController.swift
//  元组第一讲
//
//  Created by 周希财 on 2017/10/25.
//  Copyright © 2017年 VIC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //第一讲 第一节
        //元组时Swift编程语言中唯一的一中复合类型，它可以将指定有限个数的任何类型一次整理为一个对象。
        //元组形式：(type1, type2, type3, ... , typen)，其中每一种类型都可以是任意的结构体、枚举或类类型，升值也可以是一个元组以及空元组。元组中的每个元素我们也可以称为它为一个分量（component）。
        enum MyEnum{
            case one, two, three
        }
        class MyClass{
            var member = 0
        }
        
        //声明一个元组常量tuple，其类型为（Int， Myenum，MyClass）
        let tuple:(Int, MyEnum, MyClass) = (10, .one, MyClass())
        //声明了元组常量tuple2，其类型为（Int,（Int, Double, bool）, Int）
        let tuple2 = (10, (20, 10.5 , true), 5)
        //*****需要注意
        //如果我们要表示一个元组，那么圆括号中必须至少有两个元素，否则圆括号将被视为圆括号操作符，而不是一个元组字面量。我们看下面一个例子：
        var a = (100)
        
        print("a = \(a)") //这里打印 a = 100
        
        print("a type is:\(type(of: a))") //这里打印 the type is：Int
        
        let b = (100, 200)
        
        print("b type is:\(type(of: b))") //b type is: (Int, Int)
        
        //第二节访问元组中的元素
        //如果我们想要访问一个元素的元组，可以对元组对象使用成员访问操作符（member-accesss operator）+ "." + 索引。例如：
        let tuple3 = (10, 0.5, false)

        let c = tuple3.0 //访问第一个元素

        //此外，我们还能给元组指定标签，我们可以通过访问标签名来访问相应的元素。
        
        let tuple4 = (int : 10 , double : 0.5, bool : false)
        
        let d = tuple4.double
        
        //需要注意的是，一旦一个元组的某个元素带上标签，那么该元祖类型相应的位置也必须要加上标签，此外一盒远足中不需要给所有的元素都加上标签，可以加一部分，二其余的元素可以不指定标签，对由指定标签的元素，我们既可以使用标签来访问它，也可以使用索引。
        
        let tuple5 = (int : 10 , 0.5, bool : false, "Hello")  //第二个与最后一个元素是没有标签的
        
        let e = tuple5.int //访问第一个
        let f = tuple5.1   //访问第二个
        let g = tuple5.3   //访问第四个元素
        
        // 第二节 元素分解
        
        //元素分解顾名思义就是萃取一个元组中的相应元素。我们在做元组分解时，将几个变量或常量以元组定义的方式进行声明，然后 = 操作符右边对象中的相应元素就能赋值给 = 左边的相应变量或常量了。
        let tuple6 =  (10, 20.5, true)
        
        // 这里同时声明了三个常量：
        // i、d、b。
        // 然后tuple中的第一个元素对i初始化；
        // tuple中的第二个元素对d初始化；
        // tuple中的第三个元素对b初始化
        let (h, i, j) = tuple6
        
        //如果我们不想萃取元组中某一元素的值， 我们可以用下划线进行忽略
        
        var (x, _, y) = (5.5, "hello", 8.5)
        
        x += i  // x的值为26
        y -= i  // y的值为-12
        
        // 第三节 元组比较
        //两个相同元素类型的元组，如果每个元素都遵循了Equatable协议，那么这两个元组对象可以用==操作以及 !=操作符。如果两个元租对象中的每个元素的值都相等，那么这两个元组对象是相等的，否则他们是不等的。
        //两个相同元素类型的元组，如果每个元素都遵循了 Comparable 协议，那么这两个元组可以用 > 操作符、< 操作符、 >= 操作符以及 <= 操作符来比较大小。在比较两个元组的时候，从这两个元组的第一个元素开始进行比较，如果能比较出结果，那么就立即返回比较结果，否则再依次比较下去。下面我们举一些例子来说明：
        let t1 = (1, 2, 3)
        let t2 = (1, 2, 3)
        
        // 判断元组t1与t2是否相等，
        // 结果为true
        print("t1 == t2? \(t1 == t2)")
        
        let t3 = (2, 3, 4, 5)
        let t4 = (2, 1, 7, 9)
        
        // 这里比较元组t3与t4是否为小于关系，
        // 结果为false，
        // 因为t3的第2个元素大于t4的第2个元素
        print("t3 < t4? \(t3 < t4)")
        
        // 这个比较将直接编译报错，
        // 因为这两个不是相同类型的元组
        var k = t1 < t3
        
        // 这句也会引发编译报错，
        // 因为布尔类型不遵循Comparable协议，
        // 所以不能进行比较，
        // 尽管这里的Int与Double可进行比较
        k = (true, 1, 2.0) > (false, 2, -1.0)
        
        
        //第四节 空元组
        //所谓空元组就是一个不包含任何元素的元组，即 ().Swift编程语言中对空元组有一个非常特殊的定义——既可以将它用来作为对象或函数的类型进行声明，也可以将它作为右值。当作为对象或函数的类型声明时，它表示无，即相当于C语言中的 void 。当作为类型使用时，我们往往使用 Void 来显式标出。在Swift编程语言中，Void 其实就是用空元组来定义的。当空元组作为右值时，它表示一个空表达式，并且类型为 Void。这里大家要注意的是，如果空元组作为右值使用，那么就不能写 Void，而必须直接用 ()。因为 Void 是以类型的方式定义的，而不是以值的方式。
        //空表达式（即 void 表达式）与空值表达式（nil 表达式）是有本质区别的。前者表示不具有任何类型，除了通配符（_）以及表示 Void 的对象之外，不能赋值给其它任何类型的对象。而空值 nil 则可赋值给任一Optional对象，表示其当前引用为空。我们下面来举一些例子进行说明：
        // 声明一个Void类型的常量v
        let v: Void

        // 用空元组对v初始化
        v = ()
        
        // 将v赋值给缺省对象说明符，
        // 这条语句是一条空语句，
        // 编译器会直接将它忽略
        _ = v
        var l = 10
        
        // 这里需要对result显式标明Void类型，
        // 否则会有编译警告
        let result: Void = l += 100
        
        // 空元组值也可以被打印出来，
        // 输出：result = (), a = 110
        print("result = \(result), a = \(l)")
        
        // 这里先提前提一下，
        // 空元组也能赋值给Any类型的对象
        let obj: Any = result
        
        // 我们甚至还可以用is来判断Void对象的类型
        let isVoid = obj is Void
        
        // 输出：isVoid? true
        print("isVoid? \(isVoid)")
        
        
        }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

